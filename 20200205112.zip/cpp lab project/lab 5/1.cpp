#include<iostream>
using namespace std;
float average (float x1 , float x2 , float x3 , float x4){
    return (x1+x2+x3+x4)/4;
}
int main()
{
    cout<<average(1.1,2.2,3.3,4.4);
}

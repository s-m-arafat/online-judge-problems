#include<iostream>
using namespace std;
int main()
{
    float centimeter;
    cout<<"Centimeters:" <<endl;
    cin>>centimeter;
    float inches=centimeter*0.393;
    cout<<"Inches:"<<endl<<inches<<endl;
    return 0;
}

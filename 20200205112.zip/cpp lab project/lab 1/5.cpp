#include<iostream>
using namespace std;
int main()
{
    cout<<"*********\t     ***\t       *\t  *\n"
        <<"*\t*\t   *     *\t      ***\t * *\n"
        <<"*\t*\t  *\t  *\t     *****      *   *\n"
        <<"*\t*\t  *\t  *\t       *       *     *\n"
        <<"*\t*\t  *\t  *\t       *      *\t      *\n"
        <<"*\t*\t  *\t  *\t       *       *     *\n"
        <<"*\t*\t  *\t  *\t       *\t*   *\n"
        <<"*\t*\t   *\t *\t       *\t * *\n"
        <<"*********\t     ***\t       *\t  *\n";
    return 0;
}

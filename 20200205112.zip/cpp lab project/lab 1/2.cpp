#include<iostream>
using namespace std;
int main()
{
    cout<<"Patri";
    cout<<"ot "<<"G";
    cout<<"a"<<"m"<<"e"<<"\n";
    cout<<"B"<<"y"<<"\n";
    cout<<"\t\t Tom"<<" "<<"C";
    cout<<"lancy\n\n\n";
    return 0;
}

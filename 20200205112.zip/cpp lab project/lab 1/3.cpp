#include<iostream>
using namespace std;
int main()
{
    cout<<"My favourite colours: "<<endl<<endl;
    cout<<"Red, Pink, Green, Black, Yellow, Blue"<<endl<<endl;
    cout<<"Red\nPink\nGreen\nBlack\nYellow\nBlue"<<endl<<endl;
    cout<<"Red\tPink\nGreen\tBlack\nYellow\tBlue"<<endl;
    return 0;
}

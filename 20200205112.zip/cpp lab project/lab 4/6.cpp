#include<iostream>
using namespace std;
int main()
{
    int n=0, sum=0;
    for(int i=0; n>=0; i++){
        sum+=n;
        cin>>n;
    }
    cout<<sum<<endl;
    return 0;
}
